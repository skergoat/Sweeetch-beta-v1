Testing the Bundle
==================

In order to run the UnitTests of this bundle, clone it first

    $> git clone git://github.com/1up-lab/OneupFlysystemBundle.git

After the cloning process, install all vendors by running the corresponding composer command.

    $> php composer.phar update --dev

## Run UnitTests
You can run the unit tests by simply performing the follwowing command.

    $> phpunit
