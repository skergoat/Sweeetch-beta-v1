<?php

namespace Oneup\FlysystemBundle\DependencyInjection\Factory;

interface AdapterFactoryInterface extends FactoryInterface
{
}
