<?php

namespace Oneup\FlysystemBundle\DependencyInjection\Factory;

interface CacheFactoryInterface extends FactoryInterface
{
}
