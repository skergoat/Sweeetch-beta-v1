<?php

/*
 * This file is part of the `liip/LiipImagineBundle` project.
 *
 * (c) https://github.com/liip/LiipImagineBundle/graphs/contributors
 *
 * For the full copyright and license information, please view the LICENSE.md
 * file that was distributed with this source code.
 */

namespace Liip\ImagineBundle\Exception\Config\Filter;

use Liip\ImagineBundle\Exception\ExceptionInterface;

class NotFoundException extends \Exception implements ExceptionInterface
{
}
