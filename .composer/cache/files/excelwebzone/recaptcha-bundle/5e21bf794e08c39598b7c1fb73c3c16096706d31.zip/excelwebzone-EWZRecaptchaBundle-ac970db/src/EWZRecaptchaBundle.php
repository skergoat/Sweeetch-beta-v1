<?php

namespace EWZ\Bundle\RecaptchaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EWZRecaptchaBundle extends Bundle
{
}
