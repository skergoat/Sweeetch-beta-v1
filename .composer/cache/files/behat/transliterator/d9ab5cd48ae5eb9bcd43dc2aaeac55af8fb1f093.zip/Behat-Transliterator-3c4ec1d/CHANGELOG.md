# 1.3.0 / 2020-01-14

-   Fix existing Travis CI builds
-   Add CI builds for all PHP versions between 5.3 and 7.4 
-   Add preliminary support for PHP 7.4 

# 1.2.0 / 2017-04-04

-   Stop Transliterator::postProcessText() breaking words containing apostrophes

# 1.1.0 / 2015-09-28

-   Updated unicode bank files
-   Added a testsuite for the library

# 1.0.1 / 2014-05-14

-   fixed the regex used to replace non-word characters

# 1.0.0 / 2014-01-12

-   Initial release as a standalone component
