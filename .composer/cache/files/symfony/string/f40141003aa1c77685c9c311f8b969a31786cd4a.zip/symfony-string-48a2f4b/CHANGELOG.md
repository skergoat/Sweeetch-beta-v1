CHANGELOG
=========

5.0.0
-----

 * added the component as experimental
