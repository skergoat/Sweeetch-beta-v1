<?php

declare(strict_types=1);

namespace ProxyManager\Stub;

/**
 * Just an empty instantiable class
 *
 * @author Marco Pivetta <ocramius@gmail.com>
 * @license MIT
 */
final class EmptyClassStub
{
}
