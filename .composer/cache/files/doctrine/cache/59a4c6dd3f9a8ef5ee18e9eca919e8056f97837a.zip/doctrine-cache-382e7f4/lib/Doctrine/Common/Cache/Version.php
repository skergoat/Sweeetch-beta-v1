<?php

namespace Doctrine\Common\Cache;

class Version
{
    public const VERSION = '1.9.0-DEV';
}
