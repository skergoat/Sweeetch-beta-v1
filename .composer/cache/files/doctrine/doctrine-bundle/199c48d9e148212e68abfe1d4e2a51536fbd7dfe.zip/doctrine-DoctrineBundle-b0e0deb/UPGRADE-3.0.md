UPGRADE FROM 2.x to 3.0
=======================

Types
-----

 * The `commented` configuration option for types is no longer supported and
 deprecated.
